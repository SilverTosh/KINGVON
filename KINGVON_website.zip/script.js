document.getElementById('toggle-music').addEventListener('click', function() {
    let music = document.getElementById('background-music');
    if (music.paused) {
        music.play();
        this.textContent = 'Pause';
    } else {
        music.pause();
        this.textContent = 'Play';
    }
});
